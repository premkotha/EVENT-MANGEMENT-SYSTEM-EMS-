package com.event_management.event_management_system_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
