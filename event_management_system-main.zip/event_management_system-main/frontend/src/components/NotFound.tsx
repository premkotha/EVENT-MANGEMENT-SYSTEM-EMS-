import React from 'react'

const NotFound = () => {
  return (
    <div>
      NOT FOUND
    </div>
  )
}

export default NotFound
